**Project Groot**

_Description_

Groot is a web server which provides HTML5 GUI and Python backend(along with little bash).

It allows people test their Puppet modules and see the compile results in Groot GUI.

_TODO LIST_

1. Create a web server to handle basic request

2. Create a bash script to automatically retrieve Puppet code 
from Git
3. Create a web page for people to select which Puppet module they want to
compile
4. Output the Puppet compile logs on the web page

5. Remove unused CSS, JS