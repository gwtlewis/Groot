#!/usr/bin/env bash

dir=$(pwd)

${dir}/bin/start.sh -p ${dir}

exit 0